var LinkedListElement = /** @class */ (function () {
    function LinkedListElement(n) {
        this.value = n;
        this.next = null;
    }
    return LinkedListElement;
}());
var LinkedListIterator = /** @class */ (function () {
    function LinkedListIterator(e) {
        this.curr = e;
    }
    LinkedListIterator.prototype.next = function () {
        if (this.curr == null) {
            return { done: true, value: null };
        }
        else {
            var v_1 = this.curr.value;
            this.curr = this.curr.next;
            return { done: false, value: v_1 };
        }
    };
    return LinkedListIterator;
}());
var LinkedList = /** @class */ (function () {
    function LinkedList() {
        this.length = 0;
        this.head = null;
    }
    LinkedList.prototype.pushBack = function (n) {
        if (this.head == null) {
            this.head = new LinkedListElement(n);
        }
        else {
            var h = this.head;
            while (h.next != null) {
                h = h.next;
            }
            h.next = new LinkedListElement(n);
        }
        this.length += 1;
    };
    LinkedList.prototype.popFront = function () {
        if (this.length == 0) {
            throw new RangeError("Empty list");
        }
        var v = this.head.value;
        this.head = this.head.next;
        this.length -= 1;
        return v;
    };
    LinkedList.prototype.iterate = function () {
        return new LinkedListIterator(this.head);
    };
    LinkedList.prototype.toString = function () {
        return "List of length: " + this.length;
    };
    return LinkedList;
}());
var ll = new LinkedList();
ll.pushBack(1);
ll.pushBack(2);
ll.pushBack(3);
ll.pushBack(4);
console.log("Iterate:");
var iterator = ll.iterate();
var v;
while (!(v = iterator.next()).done) {
    console.log(v.value);
}
console.log(ll + "");
console.log(ll.popFront());
console.log(ll.popFront());
console.log(ll.popFront());
console.log(ll.popFront());
try {
    console.log(ll.popFront());
}
catch (e) {
    console.log(e);
}
