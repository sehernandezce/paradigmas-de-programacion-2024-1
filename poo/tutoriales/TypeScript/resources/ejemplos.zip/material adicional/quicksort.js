var QuickSort = /** @class */ (function () {
    function QuickSort() {
    }
    QuickSort.prototype.sort = function (array) {
        this.quicksort(array);
    };
    QuickSort.prototype.quicksort = function (a, left, right) {
        if (left === void 0) { left = 0; }
        if (right === void 0) { right = a.length - 1; }
        if (left < right) {
            var pivot = right;
            var idx = this.partition(a, pivot, left, right);
            this.quicksort(a, left, idx - 1);
            this.quicksort(a, idx + 1, right);
        }
        return a;
    };
    QuickSort.prototype.partition = function (a, pivot, left, right) {
        var pvalue = a[pivot];
        var part_idx = left;
        for (var i = left; i < right; i++) {
            if (a[i] < pvalue) {
                _a = [a[part_idx], a[i]], a[i] = _a[0], a[part_idx] = _a[1];
                part_idx++;
            }
        }
        _b = [a[part_idx], a[right]], a[right] = _b[0], a[part_idx] = _b[1];
        return part_idx;
        var _a, _b;
    };
    return QuickSort;
}());
var number_array = [2, 8, 1, 4, 6, 5, 3];
console.log(number_array);
new QuickSort().sort(number_array);
console.log(number_array);
var string_array = ["bb", "ba", "aa", "ca", "ac", "de"];
console.log(string_array);
new QuickSort().sort(string_array);
console.log(string_array);
