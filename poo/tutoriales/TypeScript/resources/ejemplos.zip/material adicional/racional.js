var Racional = /** @class */ (function () {
    function Racional(numerador, denominador) {
        if (numerador === void 0) { numerador = 0; }
        if (denominador === void 0) { denominador = 1; }
        if (denominador == 0) {
            throw new RangeError("El denominador no puede tener el valor 0.");
        }
        this.numerador = numerador;
        this.denominador = denominador;
        this.reducir();
    }
    Racional.gcd = function (a, b) {
        while (b != 0) {
            var t = b;
            b = a % b;
            a = t;
        }
        return a;
    };
    Racional.prototype.reducir = function () {
        var gcd = Racional.gcd(this.numerador, this.denominador);
        this.numerador /= gcd;
        this.denominador /= gcd;
    };
    Racional.prototype.suma = function (a) {
        return new Racional(this.numerador * a.denominador + a.numerador * this.denominador, this.denominador * a.denominador);
    };
    Racional.prototype.multiplicacion = function (a) {
        return new Racional(this.numerador * a.numerador, this.denominador * a.denominador);
    };
    Racional.prototype.menor = function (a) {
        return this.numerador * a.denominador < this.denominador * a.numerador;
    };
    Racional.prototype.igual = function (a) {
        return this.numerador * a.denominador == this.denominador * a.numerador;
    };
    Racional.prototype.toReal = function () {
        return this.numerador / this.denominador;
    };
    Racional.prototype.toString = function () {
        if (this.denominador == 1) {
            return "(" + this.numerador + ")";
        }
        else {
            return "(" + this.numerador + "/" + this.denominador + ")";
        }
    };
    return Racional;
}());
var a = new Racional();
var b = new Racional(1, 3);
var c = new Racional(4, 3);
var d = new Racional(3, 2);
console.log("a=" + a + "=" + a.toReal());
console.log("b=" + b + "=" + b.toReal());
console.log("c=" + c);
console.log("d=" + d);
var e = c.suma(d);
var f = c.multiplicacion(d);
var g = c.multiplicacion(b);
console.log("e=" + c + "+" + d + "=" + e);
console.log("f=" + c + "*" + d + "=" + f);
console.log("g=" + c + "*" + b + "=" + g);
try {
    var h = new Racional(1, 0);
}
catch (e) {
    console.log(e);
}
var i = c.menor(a);
var j = b.menor(c);
var k = b.igual(c);
console.log("i=" + c + "<" + a + "=" + i);
console.log("j=" + b + "<" + c + "=" + j);
console.log("k=" + b + "==" + c + "=" + k);
var l = new Racional(2, 6);
console.log("l=" + l);
var m = l.igual(b);
console.log("m=" + l + "==" + b + "=" + m);
var n = l.menor(b);
console.log("n=" + l + "<" + b + "=" + n);
